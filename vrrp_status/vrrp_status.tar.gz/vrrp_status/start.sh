#!/bin/bash
cppython vrrp_status.py