Application Name
================
vrrp_status


Application Version
===================
0.2


NCOS Devices Supported
======================
ALL


External Requirements
=====================
VRRP enabled on at least one LAN

Application Purpose
===================
This application will set the device asset ID to visually show
the VRRP status


Expected Output
===============
Asset ID updated every 5 seconds
Log printed

