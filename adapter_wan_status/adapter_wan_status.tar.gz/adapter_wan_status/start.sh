#!/bin/bash
cppython adapter_wan_status.py